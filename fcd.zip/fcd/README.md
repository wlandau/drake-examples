# Fixed-Choice Design Simulation 

This simulation compares the structural characteristics of a social network under a fixed-choice design (see [Kossinets, 2006](https://arxiv.org/abs/cond-mat/0306335) for more information) to the "true" network of interest.
