# module load R # for clusters
nohup R CMD BATCH run.R &
