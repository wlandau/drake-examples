This example demonstrates the use of the DBI cache. It requires the DBI and RSQLite packages.

More information: <https://books.ropensci.org/drake/storage.html#caches>
