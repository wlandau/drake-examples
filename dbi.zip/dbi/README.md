This example demonstrates the use of the DBI cache. It requires the DBI and RSQLite packages.

More information: https://ropenscilabs.github.io/drake-manual/store.html#caches
