https://github.com/wlandau/drake-examples
