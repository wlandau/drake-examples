This example `drake` workflow analyzes the [`gapminder` dataset](https://github.com/jennybc/gapminder) to explore associations among GDP, life expectancy, and population.
