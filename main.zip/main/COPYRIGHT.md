Copyright Eli Lilly and Company
