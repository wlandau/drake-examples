This is the example from [this chapter of the user manual](https://books.ropensci.org/drake/walkthrough.html). Originally written by [Kirill Müller](https://github.com/krlmlr).
