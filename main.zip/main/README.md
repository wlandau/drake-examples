This is the example from [this chapter of the user manual](https://ropenscilabs.github.io/drake-manual/walkthrough.html). Originally written by [Kirill Müller](https://github.com/krlmlr).
