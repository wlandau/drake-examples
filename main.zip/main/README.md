This is the example from [this chapter of the user manual](https://ropenscilabs.github.io/drake-manual/intro.html). Originally written by [Kirill Müller](https://github.com/krlmlr).
