# Load our packages in the usual way.
# This example requires packages forcats, readxl, and rmarkdown,
# but you do not need to load them here.
library(drake)
require(dplyr)
require(ggplot2)
require(tidyr)
