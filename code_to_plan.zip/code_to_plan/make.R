# Visit https://ropenscilabs.github.io/drake-manual/plans.html
# to learn about workflow plan data frames in drake.

library(drake)

# Get a workflow plan data frame from an R script

# Run the worklflow with make()

# Inspect the output
readd(z)