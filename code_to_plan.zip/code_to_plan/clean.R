drake::clean(destroy = TRUE)
unlink(c("new_script.R", "new_notebook*"))
