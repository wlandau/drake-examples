This workflow is designed to maximize overhead and stress-test drake. The goal is to improve drake's internals so this example runs fast. Run the `make.R` script to for some benchmarks.
