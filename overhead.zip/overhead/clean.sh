#!/bin/bash
rm -rf *~ Makefile *.out *.proto .RData *.Rout .Rhistory
