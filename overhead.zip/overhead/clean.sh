#!/bin/bash
rm -rf *~ Makefile pdf *.proto *.Rprof
