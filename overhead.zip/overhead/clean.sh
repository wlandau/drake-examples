#!/bin/bash
rm -rf *~ Makefile *.out *.proto .RData *.Rprof *.Rout
