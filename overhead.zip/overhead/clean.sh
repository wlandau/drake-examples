#!/bin/bash
rm -rf *~ Makefile pdf *.out *.proto .RData *.Rprof *.Rout
